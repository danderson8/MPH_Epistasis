The documents the execution, required input, and resultant output, from two original analysis scripts that were developed for use in the student of the methyl-parathion hydrolase enzyme's evolution. If you use it, please cite:

"Environment-dependent epistasis defined the adaptive landscape for the evolution of the methyl-parathion hydrolase enzyme" by DW Anderson, F Baier, G Yang, N Tokuriki.


All analyses scripts run in the open-source statistical analysis software "R", which can be freely installed here: https://www.r-project.org/


The analyses are broken into two distinct scripts. 

1) Epistasis

The script "EpistasisAnalysis_withinMetals.R" (which analyzes data for a single metal environment at a time). In this case, it takes the input data file "PTM_Ca.csv", which contains all functional measurements (enzyme activity) associated with specific genotypes, which are encoded using a simplex method (see Methods from Anderson et al.). To run it, you must first install the packages for "lmtest" (https://rdrr.io/cran/lmtest/) and "qvalue" (note that for R version 4.0, the "value" package is now managed using the BiocManager package) (http://www.bioconductor.org/packages/release/bioc/html/qvalue.html).

This script then constructs a series of linear models that fit the measured function (enzyme activity) to the simplex dummy variables that represent the genetic variation that was tested (at positions 72. 193, 254, 271, 273). After fitting the first-order model (average effect of mutations at each position), it subsequently fits a "second-order" model that includes pairwise interactions between positions (epistasis). It then performs a likelihood ratio test in order to assess whether the additional interaction parameters from the more complex model are justified by the improvement in the model's fit to the functional data (see Methods for more detail).

As output, this script creates three files: First, the file "PTM_Terms_Ca.csv", which contains all the fit coefficients for each genetic variable (including all interaction effects); second, the file "PTM_R2_Terms.csv", which contains the R2 of the model fit for each linear model that is generated. These two files, together, were used to generate the figures for the paper cited above. Third, this script generates a file labelled "ROutput.txt", which contains all the printouts from the script's run. This can be used for troubleshooting, as well as to verify the p-values calculated from all likelihood ratio tests that were used to assess increasingly complex epistatic models.


2) Trajectories

Trajectory calculations were, in turn, split into two separate calculations. First, to calculate the "range overlap" between the function of each genotype with each of the genotypes that differ by a single mutation, we run the script "CalculateTrajectories.r", which takes the input data file "Coordinates_error.csv" (which is specific for one metal environment), which contains all the functional measurements for all genotypes tested, with genotypes encoded using the simplex method (see Methods for more detail). it attempts to account for ambiguous steps by considering whether there is any overlap in the range of replicate measurements (three for each genotype) for a proposed "step" in a trajectory. This is details in the output file "TrajFile.txt", which shows either an improvement for a mutation with no overlap ("1"), a decrease in function for a mutation with no overlap ("0"), or some degree of overlap (between "0" and "1"). 

The next step of this analysis utilizes the script "Trajectories_avg.r", which takes the data file "Coordinates.csv" (in this case, this will analyze trajectories for all metal environments, sequentially). It then computes, for each possible genotype across the entire genetic network, the "best" trajectory of evolutionary changes that would be fixed under the model of very strong Darwinian selection (directional selection). This trajectory is output in the file "TrajFile.1.txt" (for metal environment 1 - in this case, the Ca environment), "TrajFile.2.txt", ..."TrajFile.3.txt". 

Note that for these analyses, genotypes are encoded in the output files using a different method (specified below). Additionally, simplex genotype variables have all been re-encoded by adding "2" to each (so the ancestral state is now encoded by "1" and the derived state is now encoded by "3"). 

Together, these output files were interpreted in order to depict the trajectories across this adaptive landscape (see Figure 3 in main paper).


Custom encoding for Trajectory analysis, each number detailed corresponds to the simplex variables that follow, in the following order: pos72. pos193, pos258, pos271, pos273
    
1: -1, -1, -1, -1, -1
2: 1, -1, -1, -1, -1
3: -1, 1, -1, -1, -1
4: -1, -1, 1, -1, -1
5: -1, -1, -1, 1, -1
6: -1, -1, -1, -1, 1
7: 1, 1, -1, -1, -1
8: 1, -1, 1, -1, -1
9: 1, -1, -1, 1, -1
10: 1, -1, -1, -1, 1
11: -1, 1, 1, -1, -1
12: -1, 1, -1, 1, -1
13: -1, 1, -1, -1, 1
14: -1, -1, 1, 1, -1
15: -1, -1, 1, -1, 1
16: -1, -1, -1, 1, 1
17: 1, 1, 1, -1, -1
18: 1, 1, -1, 1, -1
19: 1, 1, -1, -1, 1
20: 1, -1, 1, 1, -1
21: 1, -1, 1, -1, 1
22: 1, -1, -1, 1, 1
23: -1, 1, 1, 1, -1
24: -1, 1, 1, -1, 1
25: -1, 1, -1, 1, 1
26: -1, -1, 1, 1, 1
27: 1, 1, 1, 1, -1
28: 1, 1, 1, -1, 1
29: 1, 1, -1, 1, 1
30: 1, -1, 1, 1, 1
31: -1, 1, 1, 1, 1
32: 1, 1, 1, 1, 1