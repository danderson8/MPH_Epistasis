plot_data <- read.csv("Coordinates.csv")

attach(plot_data)

#write("Avgs", file="Average_values.csv")
#write(xcoord, file="Average_values.csv", append = TRUE)
# write("Best_Steps", file="Best_Steps.txt")

# Now calculating the trajectory that takes the most positive steps, regardless of genotype or environmental change

traj_array <- array(NA, dim=c(3,3,3,3,3,8))

for (i in 1:256) {
        traj_array[pos72[i]+2, pos193[i]+2, pos258[i]+2, pos271[i]+2, pos273[i]+2, zcoord[i]] = xcoord[i]
}

# write("pos72, pos193, pos258, pos271, pos273, metal", file="TrajFile_Ni.txt")

# write("1, 1, 1, 1, 1, 8", file="TrajFile_Ni.txt", append=TRUE)

# Computing Trajectory


for (h in 1:8) {
    endpoints <- array(0, dim=c(3,3,3,3,3))
    write("pos72, pos193, pos258, pos271, pos273, metal", file=paste("TrajFile",h,"txt", sep="."))
    #write("pos72, pos193, pos258, pos271, pos273, metal", file=paste("EndPoints_raw",h,"txt", sep="."))
    #write("pos72, pos193, pos258, pos271, pos273, metal", file=paste("EndPoints",h,"txt", sep="."))


    for (i in c(1,3)) {
        for (j in c(1,3)) {
            for (k in c(1,3)) {
                for (l in c(1,3)) {
                    for (m in c(1,3)) {
                    
                        point <- c(i, j, k, l, m, h)
                        
                        write(c(point[1], point[2], point[3], point[4], point[5], point[6]), file=paste("TrajFile", h, "txt", sep="."), sep=",", ncol=6, append = TRUE)
                    
                        repeat {
                            step = 0
                        # Test each possible genetic mutation and environmental change
                            if (point[1]==1) {
                                test_72 <- c(point[1]+2, point[2], point[3], point[4], point[5], point[6])
                            }
                            if (point[1]==3) {
                                test_72 <- c(point[1]-2, point[2], point[3], point[4], point[5], point[6])
                            }
                            diff_72 <- traj_array[test_72[1], test_72[2], test_72[3], test_72[4], test_72[5], test_72[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
                        
                        
                            if (point[2]==1) {
                                test_193 <- c(point[1], point[2]+2, point[3], point[4], point[5], point[6])
                            }
                            if (point[2]==3) {
                                test_193 <- c(point[1], point[2]-2, point[3], point[4], point[5], point[6])
                            }
                            diff_193 <- traj_array[test_193[1], test_193[2], test_193[3], test_193[4], test_193[5], test_193[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
                        
                        
                            if (point[3]==1) {
                                test_258 <- c(point[1], point[2], point[3]+2, point[4], point[5], point[6])
                            }
                            if (point[3]==3) {
                                test_258 <- c(point[1], point[2], point[3]-2, point[4], point[5], point[6])
                            }
                            diff_258 <- traj_array[test_258[1], test_258[2], test_258[3], test_258[4], test_258[5], test_258[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
                        
                        
                            if (point[4]==1) {
                                test_271 <- c(point[1], point[2], point[3], point[4]+2, point[5], point[6])
                            }
                            if (point[4]==3) {
                                test_271 <- c(point[1], point[2], point[3], point[4]-2, point[5], point[6])
                            }
                            diff_271 <- traj_array[test_271[1], test_271[2], test_271[3], test_271[4], test_271[5], test_271[6]] - traj_array[point[1], point[2],  point[3], point[4], point[5], point[6]]
                        
                        
                            if (point[5]==1) {
                                test_273 <- c(point[1], point[2], point[3], point[4], point[5]+2, point[6])
                            }
                            if (point[5]==3) {
                                test_273 <- c(point[1], point[2], point[3], point[4], point[5]-2, point[6])
                            }
                            diff_273 <- traj_array[test_273[1], test_273[2], test_273[3], test_273[4], test_273[5], test_273[6]] - traj_array[point[1], point[2],  point[3], point[4], point[5], point[6]]
                        
                        
                            #    if (point[6]=1) {
                            #    test_ <- c(point[1]+2, point[2], point[3], point[4], point[5], point[6])
                            #}
                            #if (point[1]=3) {
                            #    test_72 <- c(point[1]-2, point[2], point[3], point[4], point[5], point[6])
                            #}
                            #diff_72 <- traj_array[test_273] - traj_array[point]
                        
                            mag <- c(diff_72, diff_193, diff_258, diff_271, diff_273)
                        
                            move <- which.max(c(diff_72, diff_193, diff_258, diff_271, diff_273))
                        
                           # write(c(point, mag[move]), file="Best_Steps.txt", append=TRUE)
                        
                            if (move==1 & mag[move]>0) {
                                step = 1
                                old_point = point
                                point = test_72
                            }
                        
                            if (move==2 & mag[move]>0) {
                                step = 1
                                old_point = point
                                point = test_193
                            }
                        
                            if (move==3 & mag[move]>0) {
                                step = 1
                                old_point = point
                                point = test_258
                            }
                        
                            if (move==4 & mag[move]>0) {
                                step = 1
                                old_point = point
                                point = test_271
                            }
                        
                            if (move==5 & mag[move]>0) {
                                step = 1
                                old_point = point
                                point = test_273
                            }
                            
                            
                        
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==1 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 1
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==1 & point[4]==1 & point[5]==1) {
                                point_print = 1
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==1 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 2
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==1 & point[4]==1 & point[5]==1) {
                                point_print = 2
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==1 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 3
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==1 & point[4]==1 & point[5]==1) {
                                point_print = 3
                            }
                            
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==3 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 4
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==3 & point[4]==1 & point[5]==1) {
                                point_print = 4
                            }
                            
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==1 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 5
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==1 & point[4]==3 & point[5]==1) {
                                point_print = 5
                            }
                            
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==1 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 6
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==1 & point[4]==1 & point[5]==3) {
                                point_print = 6
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==1 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 7
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==1 & point[4]==1 & point[5]==1) {
                                point_print = 7
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==3 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 8
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==3 & point[4]==1 & point[5]==1) {
                                point_print = 8
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==1 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 9
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==1 & point[4]==3 & point[5]==1) {
                                point_print = 9
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==1 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 10
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==1 & point[4]==1 & point[5]==3) {
                                point_print = 10
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==3 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 11
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==3 & point[4]==1 & point[5]==1) {
                                point_print = 11
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==1 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 12
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==1 & point[4]==3 & point[5]==1) {
                                point_print = 12
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==1 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 13
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==1 & point[4]==1 & point[5]==3) {
                                point_print = 13
                            }
                            
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==3 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 14
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==3 & point[4]==3 & point[5]==1) {
                                point_print = 14
                            }
                            
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==3 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 15
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==3 & point[4]==1 & point[5]==3) {
                                point_print = 15
                            }
                            
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==1 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 16
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==1 & point[4]==3 & point[5]==3) {
                                point_print = 16
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==3 & old_point[4]==1 & old_point[5]==1) {
                                old_print = 17
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==3 & point[4]==1 & point[5]==1) {
                                point_print = 17
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==1 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 18
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==1 & point[4]==3 & point[5]==1) {
                                point_print = 18
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==1 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 19
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==1 & point[4]==1 & point[5]==3) {
                                point_print = 19
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==3 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 20
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==3 & point[4]==3 & point[5]==1) {
                                point_print = 20
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==3 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 21
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==3 & point[4]==1 & point[5]==3) {
                                point_print = 21
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==1 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 22
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==1 & point[4]==3 & point[5]==3) {
                                point_print = 22
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==3 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 23
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==3 & point[4]==3 & point[5]==1) {
                                point_print = 23
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==3 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 24
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==3 & point[4]==1 & point[5]==3) {
                                point_print = 24
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==1 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 25
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==1 & point[4]==3 & point[5]==3) {
                                point_print = 25
                            }
                            
                            if (old_point[1]==1 & old_point[2]==1 & old_point[3]==3 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 26
                            }
                            
                            if (point[1]==1 & point[2]==1 & point[3]==3 & point[4]==3 & point[5]==3) {
                                point_print = 26
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==3 & old_point[4]==3 & old_point[5]==1) {
                                old_print = 27
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==3 & point[4]==3 & point[5]==1) {
                                point_print = 27
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==3 & old_point[4]==1 & old_point[5]==3) {
                                old_print = 28
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==3 & point[4]==1 & point[5]==3) {
                                point_print = 28
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==1 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 29
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==1 & point[4]==3 & point[5]==3) {
                                point_print = 29
                            }
                            
                            if (old_point[1]==3 & old_point[2]==1 & old_point[3]==3 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 30
                            }
                            
                            if (point[1]==3 & point[2]==1 & point[3]==3 & point[4]==3 & point[5]==3) {
                                point_print = 30
                            }
                            
                            if (old_point[1]==1 & old_point[2]==3 & old_point[3]==3 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 31
                            }
                            
                            if (point[1]==1 & point[2]==3 & point[3]==3 & point[4]==3 & point[5]==3) {
                                point_print = 31
                            }
                            
                            if (old_point[1]==3 & old_point[2]==3 & old_point[3]==3 & old_point[4]==3 & old_point[5]==3) {
                                old_print = 32
                            }
                            
                            if (point[1]==3 & point[2]==3 & point[3]==3 & point[4]==3 & point[5]==3) {
                                point_print = 32
                            }
                            
                            
                            if (step==0) {
                                write(paste("DONE", "NEXT TRAJECTORY", sep="\n"), file=paste("TrajFile", h, "txt", sep="."), append=TRUE)
                                #write(c(point[1], point[2], point[3], point[4], point[5], point[6]), file=paste("EndPoints_raw", h, "txt", sep="."), append=TRUE)
                                endpoints[point[1], point[2], point[3], point[4], point[5]] = endpoints[point[1], point[2], point[3], point[4], point[5]] + 1
                                break
                            }
                        
                        
                            write(paste(old_print, "->", point_print, sep=""), file=paste("TrajFile", h, "txt", sep="."), sep=",", append = TRUE)
                        
                        }
  
                    
                    
                    }
                }
            }
        }
    }
    #write("EndPoints", file=paste("Endpoints", h, "txt", sep="."))
    #write("pos72, pos193, pos258, pos271, pos273, Total", file=paste("Endpoints", h, "txt", sep="."), append=TRUE)
    
    #for (o in c(1,3)) {
    #    for (p in c(1,3)) {
    #        for (q in c(1,3)) {
    #            for (r in c(1,3)) {
    #                for (s in c(1,3)) {
    #                    if (endpoints[o,p,q,r,s] > 0) {
    #                            write(c(o,p,q,r,s,endpoints[o,p,q,r,s]), file=paste("Endpoints", h, "txt", sep="."), append=TRUE, ncol=6)
    #                    }
    #                }
    #            }
    #        }
    #    }
    #}

}
point <- c(1, 1, 1, 1, 1, 8)

repeat {
    step = 0
    # Test each possible genetic mutation and environmental change
    if (point[1]==1) {
        test_72 <- c(point[1]+2, point[2], point[3], point[4], point[5], point[6])
    }
    if (point[1]==3) {
        test_72 <- c(point[1]-2, point[2], point[3], point[4], point[5], point[6])
    }
    diff_72 <- traj_array[test_72[1], test_72[2], test_72[3], test_72[4], test_72[5], test_72[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
    
    
    if (point[2]==1) {
        test_193 <- c(point[1], point[2]+2, point[3], point[4], point[5], point[6])
    }
    if (point[2]==3) {
        test_193 <- c(point[1], point[2]-2, point[3], point[4], point[5], point[6])
    }
    diff_193 <- traj_array[test_193[1], test_193[2], test_193[3], test_193[4], test_193[5], test_193[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
    
    
    if (point[3]==1) {
        test_258 <- c(point[1], point[2], point[3]+2, point[4], point[5], point[6])
    }
    if (point[3]==3) {
        test_258 <- c(point[1], point[2], point[3]-2, point[4], point[5], point[6])
    }
    diff_258 <- traj_array[test_258[1], test_258[2], test_258[3], test_258[4], test_258[5], test_258[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
    
    
    if (point[4]==1) {
        test_271 <- c(point[1], point[2], point[3], point[4]+2, point[5], point[6])
    }
    if (point[4]==3) {
        test_271 <- c(point[1], point[2], point[3], point[4]-2, point[5], point[6])
    }
    diff_271 <- traj_array[test_271[1], test_271[2], test_271[3], test_271[4], test_271[5], test_271[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
    
    
    if (point[5]==1) {
        test_273 <- c(point[1], point[2], point[3], point[4], point[5]+2, point[6])
    }
    if (point[5]==3) {
        test_273 <- c(point[1], point[2], point[3], point[4], point[5]-2, point[6])
    }
    diff_273 <- traj_array[test_273[1], test_273[2], test_273[3], test_273[4], test_273[5], test_273[6]] - traj_array[point[1], point[2], point[3], point[4], point[5], point[6]]
    
    
    #    if (point[6]=1) {
    #    test_ <- c(point[1]+2, point[2], point[3], point[4], point[5], point[6])
    #}
    #if (point[1]=3) {
    #    test_72 <- c(point[1]-2, point[2], point[3], point[4], point[5], point[6])
    #}
    #diff_72 <- traj_array[test_273] - traj_array[point]
    
    mag <- c(diff_72, diff_193, diff_258, diff_271, diff_273)
    
    move <- which.max(c(diff_72, diff_193, diff_258, diff_271, diff_273))
    
    if (move==1 & mag[move]>0) {
        step = 1
        point = test_72
    }
    
    if (move==2 & mag[move]>0) {
        step = 1
        point = test_193
    }
    
    if (move==3 & mag[move]>0) {
        step = 1
        point = test_258
    }
    
    if (move==4 & mag[move]>0) {
        step = 1
        point = test_271
    }
    
    if (move==5 & mag[move]>0) {
        step = 1
        point = test_273
    }
    
    if (step==0) {
        break
    }
    
    #write(c(point[1], point[2], point[3], point[4], point[5], point[6]), file="TrajFile_Ni.txt", sep=",", ncol=6, append = TRUE)
    
}


#s=interp(ycoord, zcoord, xcoord, duplicate="mean")

#pdf(file=paste(i,"main","pdf", sep="."))

#surface3d(s$x, s$y, s$z, main="Functional map for PT Methyl")

#dev.off()

#data_traj <- read.csv("TrajFile.txt")

#pdf(file=paste("Trajectory", "pdf", sep=".")

#attach(data_traj)

#scatterplot3d(
